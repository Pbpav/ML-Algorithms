# index row of two-dimensional array
from numpy import array
# define array
data = array([
	[11, 22],
	[33, 44],
	[55, 66]])
# index data
print(data[0,])