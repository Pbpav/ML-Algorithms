# identity matrix
from numpy import identity
I = identity(3)
print(I)